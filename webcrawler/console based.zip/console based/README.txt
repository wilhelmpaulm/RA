To set up the application

1. Execute the database provided in the folder as a .sql file
2. Set the necessary requirements such as localhost, database name, passwor and username
3. Run the .exe provided